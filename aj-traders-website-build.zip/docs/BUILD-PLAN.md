# AJ Traders — build plan and owner review register

## 1. Executive summary
A small, original industrial B2B website focused on discovering categories and starting an email conversation. Cinematic stock photography, tactile CSS depth, and an understated navy/ivory/red identity; no manufactured trust signals or inventory claims.

## 2. Repository and environment
Inspected the existing Next.js 16 App Router / React 19 / TypeScript / Tailwind 4 / Drizzle / PostgreSQL starter. npm and its lockfile already exist. Node 22.23.4, npm 10.9.9. No Git repository, README, logo, existing catalogue, or tests were present at discovery. Existing health endpoint retained. No secrets are copied into this document.

## 3. Skill verification
| Requested skill | Status | Readable path | Contribution |
| --- | --- | --- | --- |
| Impeccable | NOT INSTALLED | None found | Not invoked |
| UI UX Pro Max | NOT INSTALLED | None found | Not invoked |
| Frontend Design | NOT INSTALLED | None found | Not invoked |
| Canvas Design | NOT INSTALLED | None found | Not invoked |
Checked project .claude/skills, user ~/.claude/skills and ~/.claude/plugins, /opt/skills, /mnt/skills, and exposed configuration locations. No other readable relevant skills discovered. This environment exposes development tools, not a Claude Code skill registry. No plugins installed.

## 4. Facts, assumptions, missing information
Confirmed: AJ Traders; owner M. Afeef Chaudhry; carbide and HSS cutting tools, CNC accessories, general order supplies; supplied Lahore address and email. Unknown: logo asset (not found), phone, WhatsApp, hours, inventory, brands, specifications, delivery, payment, returns, credentials and domain. Do not invent them. Business-name text is not a replacement logo. Owner-supplied logo must be added intact before brand sign-off.

## 5. Audience and journeys
Procurement buyers: home → categories → detail → email enquiry. Machinists: direct category → application guidance → enquiry. Local visitors: contact → full address/email. Mobile users have persistent access to navigation and enquiry actions.

## 6. Sitemap and page specifications
- /: cinematic hero; factual capabilities; featured categories; company introduction; three-step enquiry guide; local contact CTA.
- /about: confirmed business introduction, specializations, owner, location, enquiry process.
- /products: database-backed category search and group filters; explicit empty/loading/error states.
- /products/carbide-cutting-tools: overview, illustrative examples, enquiry checklist.
- /products/hss-cutting-tools: accessible introduction, examples, enquiry checklist.
- /products/cnc-accessories: generic accessory groupings and compatibility enquiry guidance.
- /products/drilling-milling-accessories: related category and enquiry checklist.
- /general-order-supplies: item-list guidance and email action.
- /contact: verified email, full address, optional local-only email-draft builder. No message-send claim.
- /privacy and /cookies: actual data/service descriptions; reviewable drafts.
- not-found: useful home, products, contact destinations and proper 404.

## 7. Visual identity and system
Deep navy #07182F, restrained red #D52635, ivory #F7F7F3, charcoal #172438. Legible self-hosted sans-serif; editorial headings, 1280px content grid, 8px spacing rhythm, subtle corners, thin rules, strong focus rings. Desktop four-column category grid; tablet two; mobile one. Reference guehring.com studied only for industrial storytelling and taxonomy, with no reused assets, copy, or layout.

## 8. Hero and motion
An editorial close-up of a milling cutter, layered over a navy field with precise graphic rules. Gentle image depth on pointer movement; no WebGL dependency. This provides a cinematic dimensional effect without pretending to be an actual stocked product. Static photo is the fallback. Reduced-motion and coarse-pointer devices receive a still composition. Primary content is never animation-gated.

## 9–10. Stack and architecture decisions
| Decision | Recommendation | Reason | Alternative | Cost / complexity | Owner gate |
| --- | --- | --- | --- | --- | --- |
| Frontend | Existing Next.js App Router | Preserve scaffold; server-first pages | Static export | Existing OSS | None for preview |
| Styling | Tailwind + documented CSS tokens | Existing tooling; clear custom visual system | CSS modules | Low | None |
| Motion | CSS transforms | Small, accessible dimensional effect | R3F if a future real model warrants it | No heavy bundle | Future model review |
| Backend | Read-only catalogue API with Drizzle/PostgreSQL | Existing platform backend; genuine search | Typed local content alone | Small existing DB | Hosting review |
| Content | Typed source plus explicit seed | No CMS subscription or authentication | Owner-editable CMS later | Low | CMS expansion only |
| Enquiries | mailto and local draft builder | Confirmed email; no provider credentials | Approved verified email provider | No subscription | Provider approval if added |
| Hosting | Existing preview only | No external account or deployment | Suitable Node host with PostgreSQL | Production pricing not researched/claimed | Required for production |
| Infrastructure | One app + one existing database | No need for distributed systems | None | Minimal | No DNS/account changes |
Database model: product_categories(slug PK, names, group, descriptions, image path/alt, examples JSON, enquiry tips JSON, sort order). No customer data table. API: GET /api/categories with bounded q and validated group; health endpoint retained. All DB access uses Drizzle.

## 11. Security, privacy, accessibility, SEO
No analytics, optional cookies, embedded maps, chat, phone guesses, third-party scripts, or accounts. Self-host images and fonts. Read-only query endpoint; parameterized Drizzle queries. Security headers include content-type, referrer policy, frame restrictions and a static-compatible CSP; inline script allowance is documented as a Next.js trade-off. No claim of comprehensive security/legal certification. Semantic HTML, keyboard navigation, native dialogs, focus visibility, labels, descriptive image alt, contrast and reduced motion. Unique metadata, robots, sitemap and factual LocalBusiness JSON-LD. Production canonical origin only when SITE_URL is configured.

## 12. Content and stock imagery
Generic examples are visibly illustrative, not inventory. No prices, brands, SKUs, guarantees, ratings, customer logos or fabricated claims. Pexels sources recorded separately. Photographs do not depict AJ Traders' premises or stock. Owner supplies permission-cleared original logo and business photography later.

## 13. QA
Run Next route typegen, TypeScript, ESLint, production build, database healthcheck. Browser coverage: home-to-category-to-enquiry, live search/filters/empty state, mobile menu, correct mailto, draft builder, privacy/cookies, unknown routes, API filters, reduced motion, image loading, no horizontal overflow at mobile/tablet/desktop, and console errors. Only claim checks actually run. Lighthouse and representative-device field Core Web Vitals are not guaranteed by a successful build.

## 14. Deployment and maintenance
No public deployment, domain change, purchase, or account creation. Before production: confirm owner details, legal text, logo, canonical domain, approved host and database, backups, HTTPS and operational ownership. Rollback: host-appropriate previous immutable build plus database backup before migrations; do not drop tables or overwrite history. Existing DB has only illustrative public content. Update typed content and deliberately seed; onConflictDoNothing never overwrites existing rows. Budget targets: no 3D bundle, no marketing scripts; local responsive images and small interactions. Measure real CWV on the chosen host.

## 15. Implementation phases and acceptance
1. Discovery/content: verified facts and missing assets documented; no fake claims.
2. System/shell: responsive navigation/footer, keyboard controls and tokens.
3. Pages/catalogue: all routes, seeded read-only DB, real search/filters, category CTAs.
4. Enquiry/legal: accurate email and local draft states; no pretend submission.
5. QA: typegen/types/lint/build/health and browser journeys pass; unresolved items recorded.

## 16. Cost/external service register
Next.js, React, Tailwind, Drizzle, Lucide, Playwright: open-source dependencies, no subscription. PostgreSQL is provided in this environment. Pexels image sources and Google Fonts are downloaded into project assets; no runtime tracking embeds. No paid APIs, SaaS integrations, analytics or messaging providers. Production hosting/domain costs remain unknown until a host/domain is approved; no free-tier promises.

## 17. Owner confirmation register
Logo asset; phone/WhatsApp if wanted; verified opening hours; correct business map pin; real catalogue, stock and specs; delivery/payment/returns policies; domain/host; privacy wording. None block an honest preview. Map directions are withheld until the pin is verified.

## 18. Production approval gate
The working preview is for review. Production release, third-party accounts, provider credentials, paid services, DNS changes, and new business claims require owner confirmation. Nothing in this plan authorizes those actions.
