# Local asset sources

All stock photographs are illustrative. They are not presented as AJ Traders premises, staff, customers or stocked products. Downloaded from the media search's recommended URLs. Pexels license: https://www.pexels.com/license/ — review continued use and source terms before production. Images are cropped responsively, not product specification evidence.

| Local file | Creator | Source |
| --- | --- | --- |
| cnc-machining.jpg | Daniel Smyth | https://www.pexels.com/photo/close-up-of-a-cnc-milling-machine-20607184/ |
| milling-detail.jpg | Pixabay | https://www.pexels.com/photo/stainless-steel-drill-head-48799/ |
| cutting-tools.jpg | Pixabay | https://www.pexels.com/photo/six-gray-drill-bits-46240/ |
| hss-tools.jpg | Pixabay | https://www.pexels.com/photo/stainless-steel-drill-bits-51320/ |
| workshop.jpg | J E | https://www.pexels.com/photo/a-large-machine-shop-with-many-machines-and-tools-18569750/ |

Font: Manrope, designed by Mikhail Sharanda and collaborators, SIL Open Font License 1.1. Self-hosted WOFF2; license retained in public/fonts/OFL.txt. No runtime Google Fonts requests.

No supplied AJ Traders logo was found. The navigation displays ordinary business-name text; no fabricated replacement logo is represented as the supplied asset.
