import "dotenv/config";
import { db, pool } from "../src/db";
import { productCategories } from "../src/db/schema";
import { categories } from "../src/lib/content";

async function seed() {
  await db.insert(productCategories).values(categories).onConflictDoNothing();
  console.log(`Seeded ${categories.length} illustrative product categories. No stock or pricing claims.`);
  await pool.end();
}
seed().catch(async (error) => { console.error(error); await pool.end(); process.exitCode = 1; });
