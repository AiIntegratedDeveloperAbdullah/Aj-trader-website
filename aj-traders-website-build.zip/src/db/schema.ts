import { integer, jsonb, pgTable, text } from "drizzle-orm/pg-core";

export const productCategories = pgTable("product_categories", {
  slug: text("slug").primaryKey(),
  name: text("name").notNull(),
  shortName: text("short_name").notNull(),
  group: text("category_group").notNull(),
  eyebrow: text("eyebrow").notNull(),
  description: text("description").notNull(),
  introduction: text("introduction").notNull(),
  image: text("image").notNull(),
  imageAlt: text("image_alt").notNull(),
  examples: jsonb("examples").$type<string[]>().notNull(),
  enquiryTips: jsonb("enquiry_tips").$type<string[]>().notNull(),
  sortOrder: integer("sort_order").notNull(),
});
