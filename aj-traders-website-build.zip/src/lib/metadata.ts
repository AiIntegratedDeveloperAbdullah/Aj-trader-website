import type { Metadata } from "next";

export function pageMetadata(title: string, description: string, path: string): Metadata {
  const origin = process.env.SITE_URL;
  return {
    title,
    description,
    ...(origin ? { alternates: { canonical: new URL(path, origin).toString() } } : {}),
    openGraph: { title: `${title} | AJ Traders`, description, ...(origin ? { url: new URL(path, origin).toString(), images: [{ url: new URL("/images/milling-detail.jpg", origin).toString(), width: 1200, height: 627, alt: "Illustrative precision milling cutter" }] } : {}) },
  };
}
