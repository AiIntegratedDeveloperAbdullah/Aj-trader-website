import "server-only";
import { and, asc, eq, ilike, or } from "drizzle-orm";
import { db } from "@/db";
import { productCategories } from "@/db/schema";
import type { Category } from "@/lib/content";

export async function getCategories(query = "", group = "all"): Promise<Category[]> {
  const safeQuery = query.trim().slice(0, 100).replace(/[\\%_]/g, "\\$&");
  const search = safeQuery ? or(ilike(productCategories.name, `%${safeQuery}%`), ilike(productCategories.description, `%${safeQuery}%`)) : undefined;
  const groupFilter = ["cutting", "accessories", "supplies"].includes(group) ? eq(productCategories.group, group) : undefined;
  return await db.select().from(productCategories).where(and(search, groupFilter)).orderBy(asc(productCategories.sortOrder)) as Category[];
}

export async function getCategory(slug: string): Promise<Category | null> {
  const rows = await db.select().from(productCategories).where(eq(productCategories.slug, slug)).limit(1);
  return (rows[0] as Category | undefined) ?? null;
}
