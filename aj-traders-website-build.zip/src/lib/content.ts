export const business = {
  name: "AJ Traders",
  owner: "M. Afeef Chaudhry",
  email: "m.afeefchaudhry247@gmail.com",
  address: "Rehman Street #6, Opposite DS Plaza, Brandreth Road, Lahore, Punjab, Pakistan",
  shortAddress: "Brandreth Road, Lahore, Pakistan",
};

export type Category = {
  slug: string;
  name: string;
  shortName: string;
  group: "cutting" | "accessories" | "supplies";
  eyebrow: string;
  description: string;
  introduction: string;
  image: string;
  imageAlt: string;
  examples: string[];
  enquiryTips: string[];
  sortOrder: number;
};

export const categories: Category[] = [
  {
    slug: "carbide-cutting-tools",
    name: "Carbide cutting tools",
    shortName: "Carbide tools",
    group: "cutting",
    eyebrow: "CUTTING TOOLS",
    description: "Explore tooling for your turning, milling, and metal-cutting requirements.",
    introduction: "Carbide tooling is used in many metalworking applications, including milling and turning. The right choice depends on the material, machine, operation, and finish required. Share your application with AJ Traders to enquire about suitable options and their specifications.",
    image: "/images/cutting-tools.jpg",
    imageAlt: "Illustrative close-up of metal milling tools and tool holders",
    examples: ["Carbide end mills", "Turning inserts", "Indexable cutting tools"],
    enquiryTips: ["Workpiece material and operation", "Tool dimensions or an existing reference", "Required quantity and any drawings"],
    sortOrder: 1,
  },
  {
    slug: "hss-cutting-tools",
    name: "HSS cutting tools",
    shortName: "HSS tools",
    group: "cutting",
    eyebrow: "CUTTING TOOLS",
    description: "High-speed steel tooling for drilling, threading, and everyday machining.",
    introduction: "High-speed steel (HSS) is a tool material used for drills, taps, and other cutting tools. Selection depends on the workpiece, required dimensions, and machining conditions. Let us know what you need so availability and exact details can be discussed.",
    image: "/images/hss-tools.jpg",
    imageAlt: "Illustrative assortment of steel drills and metalworking tools",
    examples: ["HSS twist drills", "Threading taps", "HSS milling cutters"],
    enquiryTips: ["Drill diameter or thread requirement", "Material to be machined", "Quantity and reference photographs"],
    sortOrder: 2,
  },
  {
    slug: "cnc-accessories",
    name: "CNC accessories",
    shortName: "CNC accessories",
    group: "accessories",
    eyebrow: "MACHINE ACCESSORIES",
    description: "Tool-holding and workshop accessories to support your machining setup.",
    introduction: "A machining setup relies on more than the cutting tool. Tool holders, collets, and related accessories need to be selected for the actual machine and application. Share your machine details and existing references before confirming suitability.",
    image: "/images/milling-detail.jpg",
    imageAlt: "Illustrative close-up of an indexable milling cutter and its holder",
    examples: ["Tool holders", "Collets and clamping accessories", "Tool-setting accessories"],
    enquiryTips: ["Machine and spindle interface", "Existing holder or accessory reference", "Required dimensions and quantity"],
    sortOrder: 3,
  },
  {
    slug: "drilling-milling-accessories",
    name: "Drilling & milling accessories",
    shortName: "Drilling & milling",
    group: "accessories",
    eyebrow: "WORKSHOP ACCESSORIES",
    description: "Explore accessory requirements for drilling and milling operations.",
    introduction: "Drilling and milling operations often call for dedicated holding, setup, and workshop accessories. Send a clear description, a reference image, or a drawing to start a conversation about your requirement.",
    image: "/images/cnc-machining.jpg",
    imageAlt: "Illustrative CNC spindle and drill working above a metal surface",
    examples: ["Drill-holding accessories", "Milling setup accessories", "Clamping and work-holding items"],
    enquiryTips: ["The operation and machine involved", "Dimensions, drawings, or reference images", "The quantity you require"],
    sortOrder: 4,
  },
  {
    slug: "general-industrial-supplies",
    name: "General industrial supplies",
    shortName: "General supplies",
    group: "supplies",
    eyebrow: "GENERAL ORDER SUPPLIES",
    description: "A direct starting point for your workshop and industrial supply enquiries.",
    introduction: "Not every requirement fits a standard category. AJ Traders also handles general order supply enquiries. Send an item list with quantities, reference information, and any important requirements. Availability, specifications, and terms are confirmed through direct discussion.",
    image: "/images/workshop.jpg",
    imageAlt: "Illustrative industrial workshop with metalworking equipment",
    examples: ["Workshop supply requirements", "General industrial items", "Requirement-based sourcing enquiries"],
    enquiryTips: ["An itemised requirement list", "Quantities and reference information", "Any essential application details"],
    sortOrder: 5,
  },
];

export const categoryHref = (slug: string) => slug === "general-industrial-supplies" ? "/general-order-supplies" : `/products/${slug}`;
export const enquiryHref = (slug?: string) => slug ? `/contact?category=${encodeURIComponent(slug)}` : "/contact";
export const emailHref = `mailto:${business.email}`;
