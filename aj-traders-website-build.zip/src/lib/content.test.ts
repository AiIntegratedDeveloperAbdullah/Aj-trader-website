import assert from "node:assert/strict";
import test from "node:test";
import { business, categories, categoryHref, emailHref, enquiryHref } from "./content";

test("confirmed contact details are preserved without an invented phone", () => {
  assert.equal(business.email, "m.afeefchaudhry247@gmail.com");
  assert.equal(business.owner, "M. Afeef Chaudhry");
  assert.equal(emailHref, `mailto:${business.email}`);
  assert.equal("phone" in business, false);
  assert.equal("whatsapp" in business, false);
});
test("the catalogue has five unique, generic categories", () => {
  assert.equal(categories.length, 5);
  assert.equal(new Set(categories.map(c => c.slug)).size, 5);
  for (const category of categories) {
    assert.match(category.slug, /^[a-z0-9-]+$/);
    assert.ok(category.examples.length > 0);
    assert.ok(category.enquiryTips.length > 0);
    assert.ok(category.image.startsWith("/images/"));
    assert.ok(category.imageAlt.toLowerCase().includes("illustrative"));
  }
});
test("illustrative categories do not contain fabricated stock, prices, or reviews", () => {
  for (const category of categories) {
    for (const field of ["price", "sku", "stock", "rating", "brand", "deliveryDays"]) assert.equal(field in category, false);
  }
});
test("category links use the intended routes", () => {
  assert.equal(categoryHref("carbide-cutting-tools"), "/products/carbide-cutting-tools");
  assert.equal(categoryHref("general-industrial-supplies"), "/general-order-supplies");
});
test("enquiry links safely encode context", () => {
  assert.equal(enquiryHref(), "/contact");
  assert.equal(enquiryHref("hss-cutting-tools"), "/contact?category=hss-cutting-tools");
  assert.equal(enquiryHref("a & b"), "/contact?category=a%20%26%20b");
});
