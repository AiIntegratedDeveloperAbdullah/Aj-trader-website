import type { Metadata } from "next";
import { CategoryDetail } from "@/components/category-detail";
import { categories } from "@/lib/content";

import { pageMetadata } from "@/lib/metadata";
export const metadata: Metadata = pageMetadata("General Order Supplies", "Share your workshop and general industrial supply requirements with AJ Traders, Brandreth Road, Lahore.", "/general-order-supplies");
export default function GeneralSuppliesPage() { return <CategoryDetail category={categories[4]} />; }
