"use client";
import Link from "next/link";
import { ArrowRight, RotateCcw } from "lucide-react";
export default function ErrorPage({ reset }: { error: Error & { digest?: string }; reset: () => void }) { return <main id="main-content" className="not-found"><div className="container"><div className="not-found-content"><p className="eyebrow"><span />LET’S FIND A WAY FORWARD</p><h1>A brief interruption.</h1><p>This page couldn’t load just now. Please try again, or use the contact page to enquire directly with AJ Traders.</p><div className="error-actions"><button className="button button-red" onClick={reset}>Try again <RotateCcw size={16} /></button><Link className="button button-outline" href="/contact">Contact AJ Traders <ArrowRight size={16} /></Link></div></div></div></main>; }
