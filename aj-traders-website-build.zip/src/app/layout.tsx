import type { Metadata } from "next";
import localFont from "next/font/local";
import type { ReactNode } from "react";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { business } from "@/lib/content";
import "./globals.css";

const manrope = localFont({ src: "../../public/fonts/manrope-latin-variable.woff2", variable: "--font-manrope", weight: "400 800", display: "swap", fallback: ["Arial", "sans-serif"] });
const origin = process.env.SITE_URL;
export const metadata: Metadata = {
  ...(origin ? { metadataBase: new URL(origin) } : {}),
  title: { default: "AJ Traders — Industrial Tools & Supplies, Lahore", template: "%s | AJ Traders, Lahore" },
  description: "Carbide and HSS cutting tools, CNC accessories, and general industrial supplies. Enquire with AJ Traders on Brandreth Road, Lahore, Pakistan.",
  openGraph: { title: "AJ Traders — Tools for the work ahead", description: "Industrial cutting tools, CNC accessories, and a straightforward way to enquire. Based in Lahore, Pakistan.", locale: "en_PK", type: "website", siteName: "AJ Traders", ...(origin ? { images: [{ url: "/images/milling-detail.jpg", width: 1200, height: 627, alt: "Illustrative precision milling cutter" }] } : {}) },
  twitter: { card: "summary_large_image" },
  robots: origin ? { index: true, follow: true } : { index: false, follow: true },
};

const structuredData = { "@context": "https://schema.org", "@type": "LocalBusiness", name: business.name, description: "Local B2B industrial cutting tools, CNC accessories and general order supplier.", email: business.email, ...(origin ? { url: origin } : {}), address: { "@type": "PostalAddress", streetAddress: "Rehman Street #6, Opposite DS Plaza, Brandreth Road", addressLocality: "Lahore", addressRegion: "Punjab", addressCountry: "PK" } };

export default function RootLayout({ children }: { children: ReactNode }) {
  return <html lang="en"><body className={manrope.variable}><a className="skip-link" href="#main-content">Skip to main content</a><Header />{children}<Footer /><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData).replace(/</g, "\\u003c") }} /></body></html>;
}
