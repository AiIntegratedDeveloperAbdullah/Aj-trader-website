import { LoaderCircle } from "lucide-react";
export default function Loading() { return <main id="main-content" className="route-loading" aria-live="polite" aria-busy="true"><div className="loading-content"><LoaderCircle className="spin" size={21} strokeWidth={1.5} /><span>Finding your starting point…</span></div></main>; }
