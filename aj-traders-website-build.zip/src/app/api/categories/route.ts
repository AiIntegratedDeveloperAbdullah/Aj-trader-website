import { getCategories } from "@/lib/catalogue";

export const dynamic = "force-dynamic";
export async function GET(request: Request) {
  const url = new URL(request.url);
  const query = url.searchParams.get("q") ?? "";
  const group = url.searchParams.get("group") ?? "all";
  if (query.length > 100 || !["all", "cutting", "accessories", "supplies"].includes(group)) return Response.json({ error: "Please use a valid group and a search of 100 characters or fewer." }, { status: 400 });
  try {
    const categories = await getCategories(query, group);
    return Response.json({ categories, total: categories.length }, { headers: { "Cache-Control": "public, max-age=30, stale-while-revalidate=60" } });
  } catch {
    return Response.json({ error: "The catalogue is temporarily unavailable. Please contact AJ Traders by email." }, { status: 503 });
  }
}
