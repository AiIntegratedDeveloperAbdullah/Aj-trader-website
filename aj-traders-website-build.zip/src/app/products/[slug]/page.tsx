import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { CategoryDetail } from "@/components/category-detail";
import { getCategory } from "@/lib/catalogue";
import { pageMetadata } from "@/lib/metadata";

export const dynamic = "force-dynamic";
type Props = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const category = await getCategory(slug);
  return category ? pageMetadata(category.name, category.description, `/products/${category.slug}`) : { title: "Category not found" };
}

export default async function CategoryPage({ params }: Props) {
  const { slug } = await params;
  const category = await getCategory(slug);
  if (!category) notFound();
  return <CategoryDetail category={category} />;
}
