import type { Metadata } from "next";
import { ProductBrowser } from "@/components/product-browser";
import { Breadcrumbs, ContactBanner } from "@/components/shared";
import { getCategories } from "@/lib/catalogue";

export const dynamic = "force-dynamic";
import { pageMetadata } from "@/lib/metadata";
export const metadata: Metadata = pageMetadata("Products & Categories", "Explore carbide and HSS cutting tools, CNC accessories, and general industrial supply categories. Enquire with AJ Traders in Lahore.", "/products");

export default async function ProductsPage({ searchParams }: { searchParams: Promise<{ q?: string; group?: string }> }) {
  const params = await searchParams;
  const query = typeof params.q === "string" ? params.q.slice(0, 100) : "";
  const group = ["cutting", "accessories", "supplies"].includes(params.group ?? "") ? params.group! : "all";
  const categories = await getCategories(query, group);
  return <main id="main-content"><section className="page-intro"><div className="container"><Breadcrumbs items={[{ label: "Products & categories" }]} /><div className="page-intro-heading"><div><p className="eyebrow"><span />OUR AREAS OF SPECIALIZATION</p><h1>Built around<br />your requirement<span className="red-period">.</span></h1></div><p>Find your starting point in cutting tools, CNC accessories, and industrial supplies. Explore a category, then get in touch to discuss the details.</p></div></div></section><ProductBrowser key={`${query}-${group}`} initialCategories={categories} initialQuery={query} initialGroup={group} /><ContactBanner compact /></main>;
}
