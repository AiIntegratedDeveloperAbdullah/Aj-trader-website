import type { MetadataRoute } from "next";
import { categories, categoryHref } from "@/lib/content";
export default function sitemap(): MetadataRoute.Sitemap {
  const origin = process.env.SITE_URL;
  if (!origin) return [];
  const paths = ["/", "/about", "/products", "/contact", "/privacy", "/cookies", ...categories.map(c => categoryHref(c.slug))];
  return [...new Set(paths)].map(path => ({ url: new URL(path, origin).toString(), changeFrequency: "monthly" as const, priority: path === "/" ? 1 : path.startsWith("/products") ? .8 : .5 }));
}
