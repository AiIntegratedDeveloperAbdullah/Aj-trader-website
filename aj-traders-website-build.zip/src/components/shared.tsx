import Link from "next/link";
import { ArrowRight, ArrowUpRight, ChevronRight } from "lucide-react";

export function Breadcrumbs({ items }: { items: { label: string; href?: string }[] }) {
  return <nav className="breadcrumbs" aria-label="Breadcrumb"><Link href="/">Home</Link>{items.map((item, index) => <span key={index}><ChevronRight size={12} />{item.href ? <Link href={item.href}>{item.label}</Link> : <span aria-current="page">{item.label}</span>}</span>)}</nav>;
}

export function ContactBanner({ compact = false }: { compact?: boolean }) {
  return <section className={`contact-banner ${compact ? "compact" : ""}`}><div className="container contact-banner-inner"><div><span className="eyebrow"><span />LET’S TALK REQUIREMENTS</span><h2>The next step starts<br />with a conversation.</h2><p>Tell us what you need. We’ll take it from there.</p></div><Link href="/contact" className="button button-red">Make an enquiry <ArrowUpRight size={20} /></Link></div></section>;
}

export function InlineLink({ href, children }: { href: string; children: React.ReactNode }) {
  return <Link href={href} className="inline-link">{children}<ArrowRight size={18} /></Link>;
}

export function ImageDisclaimer() {
  return <p className="image-disclaimer"><span /> Product categories and photography are illustrative. Enquire for availability and specifications.</p>;
}
