import Link from "next/link";
import { ArrowUpRight, Mail, MapPin } from "lucide-react";
import { business, categories, categoryHref, emailHref } from "@/lib/content";

export function Footer() {
  return <footer className="site-footer"><div className="container">
    <div className="footer-main">
      <div className="footer-brand-block"><Link href="/" className="brand footer-brand"><span className="brand-name">AJ TRADERS<span className="brand-period">.</span></span><span className="brand-tagline">INDUSTRIAL TOOLS & SUPPLIES</span></Link><p>Industrial cutting tools and CNC accessories.<br />A straightforward place to start.</p><span className="footer-location"><span className="status-dot" /> BASED IN LAHORE, PAKISTAN</span></div>
      <div className="footer-column"><h2>Explore</h2><Link href="/">Home</Link><Link href="/about">About AJ Traders</Link><Link href="/products">Product categories</Link><Link href="/contact">Contact & enquiries</Link></div>
      <div className="footer-column"><h2>Our specializations</h2>{categories.filter(c => c.slug !== "drilling-milling-accessories").map(c => <Link key={c.slug} href={categoryHref(c.slug)}>{c.name}</Link>)}</div>
      <div className="footer-column footer-contact"><h2>Let’s talk requirements</h2><a href={emailHref}><Mail size={16} /><span>{business.email}</span><ArrowUpRight size={14} /></a><p><MapPin size={17} /><span>Rehman Street #6, Opposite DS Plaza,<br />Brandreth Road, Lahore,<br />Punjab, Pakistan</span></p></div>
    </div>
    <div className="footer-bottom"><span>© {new Date().getFullYear()} AJ Traders. All rights reserved.</span><span>Tools for the work ahead.</span><div><Link href="/privacy">Privacy policy</Link><Link href="/cookies">Cookie policy</Link></div></div>
  </div></footer>;
}
