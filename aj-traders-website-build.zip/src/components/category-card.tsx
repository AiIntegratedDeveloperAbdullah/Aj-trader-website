import Image from "next/image";
import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import { categoryHref, type Category } from "@/lib/content";

export function CategoryCard({ category, index = 0 }: { category: Category; index?: number }) {
  return <Link href={categoryHref(category.slug)} className="category-card">
    <div className={`category-image category-image-${category.slug}`}><Image src={category.image} alt={category.imageAlt} fill sizes="(max-width: 600px) 100vw, (max-width: 1050px) 50vw, 30vw" /><span className="category-index">0{index + 1}</span><span className="category-image-arrow"><ArrowUpRight size={20} strokeWidth={1.5} /></span></div>
    <div className="category-card-content"><span className="category-eyebrow">{category.eyebrow}</span><h3>{category.name}</h3><p>{category.description}</p><span className="category-link">Explore category <ArrowUpRight size={15} /></span></div>
  </Link>;
}
