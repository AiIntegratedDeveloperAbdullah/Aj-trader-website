"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { ArrowRight, ArrowUpRight, ChevronDown, Mail, MapPin, Menu, Search, X } from "lucide-react";
import { useEffect, useRef, useState, type FormEvent } from "react";
import { business, categories, categoryHref, emailHref } from "@/lib/content";

export function Header() {
  const pathname = usePathname();
  const router = useRouter();
  const [productsOpen, setProductsOpen] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [query, setQuery] = useState("");
  const dropdown = useRef<HTMLDivElement>(null);
  const searchDialog = useRef<HTMLDialogElement>(null);
  const searchInput = useRef<HTMLInputElement>(null);
  const mobileDialog = useRef<HTMLDialogElement>(null);

  useEffect(() => {
    const onClick = (event: MouseEvent) => {
      if (dropdown.current && !dropdown.current.contains(event.target as Node)) setProductsOpen(false);
    };
    const onKey = (event: KeyboardEvent) => { if (event.key === "Escape") setProductsOpen(false); };
    document.addEventListener("mousedown", onClick);
    document.addEventListener("keydown", onKey);
    return () => { document.removeEventListener("mousedown", onClick); document.removeEventListener("keydown", onKey); };
  }, []);

  useEffect(() => {
    if (!mobileOpen) return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => { document.body.style.overflow = previous; };
  }, [mobileOpen]);

  function closeMenus() {
    setProductsOpen(false);
    setMobileOpen(false);
    mobileDialog.current?.close();
  }
  function openSearch() {
    closeMenus();
    searchDialog.current?.showModal();
    requestAnimationFrame(() => searchInput.current?.focus());
  }
  function submitSearch(event: FormEvent) {
    event.preventDefault();
    searchDialog.current?.close();
    router.push(`/products${query.trim() ? `?q=${encodeURIComponent(query.trim())}` : ""}`);
  }

  return (
    <header className="site-header">
      <div className="utility-bar">
        <div className="container utility-inner">
          <span>PRECISION TOOLS. STRAIGHTFORWARD SOURCING.</span>
          <div><span className="utility-location"><MapPin size={12} /> Lahore, Pakistan</span><span className="utility-divider" /><a href={emailHref}><Mail size={12} /><span>{business.email}</span></a></div>
        </div>
      </div>
      <div className="main-navigation">
        <div className="container navigation-inner">
          <Link href="/" className="brand" aria-label="AJ Traders home" onClick={closeMenus}>
            <span className="brand-name">AJ TRADERS<span className="brand-period">.</span></span>
            <span className="brand-tagline">INDUSTRIAL TOOLS & SUPPLIES</span>
          </Link>
          <nav className="desktop-nav" aria-label="Main navigation">
            <Link href="/" className={pathname === "/" ? "nav-link active" : "nav-link"}>Home</Link>
            <div className="products-nav" ref={dropdown}>
              <button type="button" className={`nav-link ${pathname.startsWith("/products") ? "active" : ""}`} aria-expanded={productsOpen} aria-controls="products-menu" onClick={() => setProductsOpen(!productsOpen)}>Products <ChevronDown size={13} className={productsOpen ? "rotated" : ""} /></button>
              {productsOpen && <div className="products-dropdown" id="products-menu">
                <span className="dropdown-label">EXPLORE OUR SPECIALIZATIONS</span>
                {categories.map((category, index) => <Link key={category.slug} href={categoryHref(category.slug)} onClick={closeMenus}><span className="dropdown-number">0{index + 1}</span><span>{category.name}</span><ArrowUpRight size={15} /></Link>)}
                <Link className="dropdown-all" href="/products" onClick={closeMenus}>View all categories <ArrowRight size={16} /></Link>
              </div>}
            </div>
            <Link href="/about" className={pathname === "/about" ? "nav-link active" : "nav-link"}>About us</Link>
            <Link href="/general-order-supplies" className={pathname === "/general-order-supplies" ? "nav-link active" : "nav-link"}>General supplies</Link>
            <Link href="/contact" className={pathname === "/contact" ? "nav-link active" : "nav-link"}>Contact</Link>
          </nav>
          <div className="nav-actions">
            <button className="icon-button search-toggle" type="button" onClick={openSearch} aria-label="Search product categories"><Search size={20} strokeWidth={1.7} /></button>
            <span className="nav-action-divider" />
            <Link href="/contact" className="button button-red header-enquiry">Make an enquiry <ArrowUpRight size={17} /></Link>
            <button className="icon-button mobile-menu-toggle" aria-label="Open navigation menu" aria-expanded={mobileOpen} aria-controls="mobile-navigation" onClick={() => { setMobileOpen(true); mobileDialog.current?.showModal(); }}><Menu size={25} /></button>
          </div>
        </div>
      </div>
      <dialog className="search-dialog" ref={searchDialog} aria-labelledby="search-heading" onClick={(e) => { if (e.target === e.currentTarget) searchDialog.current?.close(); }}>
        <div className="search-dialog-inner"><div className="dialog-top"><span className="eyebrow">FIND YOUR STARTING POINT</span><button className="icon-button" aria-label="Close search" onClick={() => searchDialog.current?.close()}><X size={23} /></button></div><h2 id="search-heading">What are you looking for?</h2><form onSubmit={submitSearch} className="global-search"><Search size={21} /><input ref={searchInput} aria-label="Search categories" maxLength={100} value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Try carbide tools or CNC accessories" /><button type="submit" className="button button-red" aria-label="Search"><ArrowRight size={21} /></button></form><p className="search-helper">Browse our areas of specialization. Enquire to confirm specific items.</p><div className="popular-searches"><span>EXPLORE</span>{categories.slice(0, 3).map(c => <Link key={c.slug} href={categoryHref(c.slug)} onClick={() => searchDialog.current?.close()}>{c.shortName}<ArrowUpRight size={14} /></Link>)}</div></div>
      </dialog>
      <dialog className="mobile-navigation-dialog" id="mobile-navigation" ref={mobileDialog} aria-label="Mobile navigation" onClose={() => setMobileOpen(false)}>
        <div className="mobile-dialog-head"><span className="brand-name">AJ TRADERS.</span><button className="icon-button" onClick={closeMenus} aria-label="Close navigation menu"><X size={26} /></button></div>
        <nav aria-label="Mobile navigation"><Link href="/" onClick={closeMenus}>Home <ArrowUpRight size={20} /></Link><Link href="/products" onClick={closeMenus}>Products <ArrowUpRight size={20} /></Link><div className="mobile-category-links">{categories.map(c => <Link key={c.slug} href={categoryHref(c.slug)} onClick={closeMenus}>{c.shortName}</Link>)}</div><Link href="/about" onClick={closeMenus}>About us <ArrowUpRight size={20} /></Link><Link href="/contact" onClick={closeMenus}>Contact <ArrowUpRight size={20} /></Link></nav>
        <div className="mobile-dialog-contact"><MapPin size={18} /><span>Brandreth Road, Lahore</span><a href={emailHref}>Email AJ Traders <ArrowRight size={17} /></a></div>
      </dialog>
    </header>
  );
}
