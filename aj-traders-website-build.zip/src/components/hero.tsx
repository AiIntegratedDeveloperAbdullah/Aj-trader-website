"use client";

import Image from "next/image";
import Link from "next/link";
import { ArrowDown, ArrowRight, ArrowUpRight, Plus } from "lucide-react";
import { useRef, type PointerEvent } from "react";

export function Hero() {
  const hero = useRef<HTMLElement>(null);
  function move(event: PointerEvent<HTMLElement>) {
    if (event.pointerType !== "mouse" || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const bounds = event.currentTarget.getBoundingClientRect();
    hero.current?.style.setProperty("--hero-x", `${(event.clientX / bounds.width - 0.5) * 7}px`);
    hero.current?.style.setProperty("--hero-y", `${((event.clientY - bounds.top) / bounds.height - 0.5) * 7}px`);
  }
  return <section className="hero" ref={hero} onPointerMove={move} onPointerLeave={() => { hero.current?.style.setProperty("--hero-x", "0px"); hero.current?.style.setProperty("--hero-y", "0px"); }}>
    <div className="hero-visual"><Image src="/images/milling-detail.jpg" alt="Illustrative studio close-up of a precision metal milling cutter with gold-toned cutting inserts" fill priority sizes="(max-width: 700px) 100vw, 80vw" quality={90} /></div>
    <div className="hero-overlay" />
    <div className="hero-grid" aria-hidden="true"><span className="hero-grid-line" /><Plus className="crosshair crosshair-one" size={19} strokeWidth={1} /><Plus className="crosshair crosshair-two" size={19} strokeWidth={1} /></div>
    <div className="container hero-content">
      <div className="hero-copy"><p className="eyebrow hero-eyebrow"><span />TOOLING FOR WHAT’S NEXT</p><h1>Precision tools.<br />For the work<br /><span className="hero-last-line">ahead<span className="red-period">.</span></span></h1><p className="hero-description">Carbide & HSS cutting tools, CNC accessories,<br className="desktop-break" /> and industrial supplies. Start with your requirement.</p><div className="hero-actions"><Link href="/products" className="button button-red">Explore product categories <ArrowRight size={18} /></Link><Link href="/contact" className="hero-enquiry">Make an enquiry <ArrowUpRight size={17} /></Link></div></div>
      <div className="hero-top-note"><span className="tiny-red-line" />PRECISION IN FOCUS<span>01 / CUTTING TOOLS</span></div>
      <div className="hero-bottom"><a href="#categories" className="hero-scroll"><span className="scroll-icon"><ArrowDown size={15} /></span><span>DISCOVER THE RIGHT STARTING POINT</span></a><div className="hero-image-caption"><span>THE DETAIL MAKES THE DIFFERENCE.</span><span>Illustrative tooling photography</span></div></div>
    </div>
  </section>;
}
