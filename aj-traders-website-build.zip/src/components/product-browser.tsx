"use client";

import { useEffect, useRef, useState } from "react";
import { ArrowRight, LoaderCircle, Search, SlidersHorizontal, X } from "lucide-react";
import Link from "next/link";
import { CategoryCard } from "@/components/category-card";
import { ImageDisclaimer } from "@/components/shared";
import type { Category } from "@/lib/content";

const groups = [{ key: "all", label: "All categories" }, { key: "cutting", label: "Cutting tools" }, { key: "accessories", label: "CNC & accessories" }, { key: "supplies", label: "General supplies" }];

export function ProductBrowser({ initialCategories, initialQuery = "", initialGroup = "all" }: { initialCategories: Category[]; initialQuery?: string; initialGroup?: string }) {
  const [query, setQuery] = useState(initialQuery);
  const [group, setGroup] = useState(initialGroup);
  const [results, setResults] = useState(initialCategories);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [retry, setRetry] = useState(0);
  const firstRender = useRef(true);
  useEffect(() => {
    if (firstRender.current) { firstRender.current = false; return; }
    const controller = new AbortController();
    const timeout = setTimeout(async () => {
      setLoading(true);
      setError("");
      const params = new URLSearchParams();
      if (query.trim()) params.set("q", query.trim());
      if (group !== "all") params.set("group", group);
      window.history.replaceState(null, "", `/products${params.size ? `?${params}` : ""}`);
      try {
        const response = await fetch(`/api/categories?${params}`, { signal: controller.signal });
        if (!response.ok) throw new Error("Unable to load categories");
        const data = await response.json() as { categories: Category[] };
        setResults(data.categories);
      } catch (err) {
        if (err instanceof Error && err.name !== "AbortError") setError("We couldn’t load the categories. Please try again, or contact us directly.");
      } finally { if (!controller.signal.aborted) setLoading(false); }
    }, 220);
    return () => { clearTimeout(timeout); controller.abort(); };
  }, [query, group, retry]);

  return <section className="catalogue-section"><div className="container"><div className="catalogue-toolbar"><div className="category-filters" aria-label="Filter by specialization">{groups.map(item => <button key={item.key} type="button" aria-pressed={group === item.key} onClick={() => setGroup(item.key)} className={group === item.key ? "filter-button selected" : "filter-button"}>{item.label}</button>)}</div><div className="catalogue-search"><Search size={18} /><input type="search" maxLength={100} placeholder="Search categories" aria-label="Search product categories" value={query} onChange={event => setQuery(event.target.value)} />{query && <button type="button" aria-label="Clear search" onClick={() => setQuery("")}><X size={16} /></button>}</div></div>
    <div className="catalogue-results-meta"><p role="status" aria-live="polite">{loading ? <><LoaderCircle size={14} className="spin" />Finding your categories…</> : <>{String(results.length).padStart(2, "0")} {results.length === 1 ? "category" : "categories"}{query && <> matching “{query}”</>}</>}</p><span><SlidersHorizontal size={13} /> SPECIALIZATIONS, NOT LIVE INVENTORY</span></div>
    {error ? <div className="catalogue-empty" role="alert"><h2>Let’s try that again.</h2><p>{error}</p><button className="button button-red" onClick={() => setRetry(retry + 1)}>Retry <ArrowRight size={16} /></button><Link href="/contact" className="inline-link">Contact AJ Traders <ArrowRight size={16} /></Link></div> : results.length ? <div className={`catalogue-grid ${loading ? "is-loading" : ""}`} aria-busy={loading}>{results.map((category, index) => <CategoryCard category={category} index={index} key={category.slug} />)}</div> : <div className="catalogue-empty"><Search size={32} strokeWidth={1.3} /><h2>No categories found.</h2><p>Try another term or clear the filters. Have a specific item in mind? You can still enquire.</p><button className="button button-navy" onClick={() => { setQuery(""); setGroup("all"); }}>Clear search & filters <X size={16} /></button><Link href="/contact" className="inline-link">Ask about your requirement <ArrowRight size={16} /></Link></div>}
    <ImageDisclaimer /></div></section>;
}
