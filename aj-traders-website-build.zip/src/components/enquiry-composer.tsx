"use client";

import { useRef, useState, type FormEvent } from "react";
import { ArrowRight, ArrowUpRight, Check, Copy, FileText, Mail } from "lucide-react";
import { business, categories } from "@/lib/content";

export function EnquiryComposer({ initialCategory = "" }: { initialCategory?: string }) {
  const [prepared, setPrepared] = useState(false);
  const [name, setName] = useState("");
  const [company, setCompany] = useState("");
  const [category, setCategory] = useState(initialCategory);
  const [requirement, setRequirement] = useState("");
  const [copied, setCopied] = useState(false);
  const [copyError, setCopyError] = useState("");
  const [validationError, setValidationError] = useState("");
  const result = useRef<HTMLDivElement>(null);
  const categoryName = categories.find(c => c.slug === category)?.name ?? "General product enquiry";
  const body = `Hello AJ Traders,\n\nI would like to enquire about: ${categoryName}\n\n${requirement}\n\nName: ${name}${company ? `\nCompany / workshop: ${company}` : ""}\n\nPlease confirm availability, specifications, and any relevant terms.\nThank you.`;
  const href = `mailto:${business.email}?subject=${encodeURIComponent(`Product enquiry — ${categoryName}`)}&body=${encodeURIComponent(body)}`;
  function prepare(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (name.trim().length < 2 || requirement.trim().length < 15) {
      setValidationError("Please enter a name with at least 2 characters and a requirement with at least 15 characters, excluding leading and trailing spaces.");
      return;
    }
    setValidationError("");
    setPrepared(true);
    setCopied(false);
    requestAnimationFrame(() => { result.current?.focus(); result.current?.scrollIntoView({ behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "instant" : "smooth", block: "nearest" }); });
  }
  async function copy() {
    try { await navigator.clipboard.writeText(`To: ${business.email}\nSubject: Product enquiry — ${categoryName}\n\n${body}`); setCopied(true); setCopyError(""); }
    catch { setCopyError("Copy is unavailable in this browser. Please select and copy the draft below."); }
  }
  if (prepared) return <div className="draft-result" ref={result} tabIndex={-1}><div className="draft-ready-label"><Check size={17} />YOUR DRAFT IS READY — NOT SENT</div><h2>Ready for your email app.</h2><p>Open the draft below, review it, and send it from your own email account. This website has not sent or stored your enquiry.</p><div className="draft-preview"><span>TO: {business.email}</span><strong>Product enquiry — {categoryName}</strong><pre>{body}</pre></div><div className="draft-actions"><a href={href} className="button button-red">Open in email app <ArrowUpRight size={17} /></a><button type="button" className="button button-outline" onClick={copy}>{copied ? <Check size={16} /> : <Copy size={16} />}{copied ? "Copied" : "Copy enquiry"}</button></div><p className="draft-feedback" role="status">{copyError || (copied ? "Enquiry copied. Paste it into an email to AJ Traders." : "If you don’t have a default email app, copy the enquiry into your webmail.")}</p><button type="button" className="inline-link" onClick={() => setPrepared(false)}>Edit your draft <ArrowRight size={15} /></button></div>;
  return <div className="enquiry-composer"><span className="eyebrow"><FileText size={15} />A USEFUL STARTING POINT</span><h2>Prepare your enquiry.</h2><p className="composer-intro">A few details make a clearer conversation. Build an email draft, then send it through your own email app.</p><form onSubmit={prepare}>{validationError && <p className="form-validation-error" role="alert">{validationError}</p>}<div className="form-row"><div className="form-field"><label htmlFor="enquiry-name">Your name <span>*</span></label><input id="enquiry-name" required minLength={2} maxLength={100} autoComplete="name" value={name} onChange={e => setName(e.target.value)} placeholder="Full name" /></div><div className="form-field"><label htmlFor="enquiry-company">Company / workshop <small>(optional)</small></label><input id="enquiry-company" maxLength={150} autoComplete="organization" value={company} onChange={e => setCompany(e.target.value)} placeholder="Company or workshop name" /></div></div><div className="form-field"><label htmlFor="enquiry-category">Area of interest</label><select id="enquiry-category" value={category} onChange={e => setCategory(e.target.value)}><option value="">General product enquiry</option>{categories.map(c => <option value={c.slug} key={c.slug}>{c.name}</option>)}</select></div><div className="form-field"><label htmlFor="enquiry-requirement">What do you need? <span>*</span></label><textarea id="enquiry-requirement" required minLength={15} maxLength={2500} rows={5} value={requirement} onChange={e => setRequirement(e.target.value)} placeholder="Tell us the item, application, dimensions, and quantity. Include any useful references." aria-describedby="requirement-help" /><small id="requirement-help">At least 15 characters. You can attach photos later in your email app.</small></div><button type="submit" className="button button-red">Prepare email draft <ArrowRight size={18} /></button><p className="form-privacy-note"><Mail size={14} /> Nothing is submitted or stored on this website.</p></form></div>;
}

export function CopyAddress() {
  const [copied, setCopied] = useState(false);
  const [failed, setFailed] = useState(false);
  return <><button type="button" className="copy-address" onClick={async () => { try { await navigator.clipboard.writeText(business.address); setCopied(true); } catch { setFailed(true); } }}>{copied ? <Check size={15} /> : <Copy size={15} />}{copied ? "Address copied" : "Copy address"}</button><span className="copy-address-status" role="status">{failed ? "Please select and copy the address above." : copied ? "The full address is on your clipboard." : ""}</span></>;
}
