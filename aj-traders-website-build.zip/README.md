# AJ Traders — industrial tools & supplies

A responsive, server-first Next.js website for a Lahore B2B industrial tools supplier. Original navy/ivory/red editorial design, self-hosted photography and type, accessible native dialogs, five illustrative categories, PostgreSQL-backed category search, and honest email enquiries.

## Start and data setup

Use the existing npm lockfile and configure DATABASE_URL in .env. Copy the placeholder structure from .env.example, never commit real credentials. Install dependencies with npm install. After the platform bootstraps the database, apply schema with `npx drizzle-kit push`, then seed with `npx tsx scripts/seed.ts`. The seed is deliberately non-destructive: onConflictDoNothing does not overwrite owner-edited rows. Use `npm run dev` for local development; the managed preview runs the production build.

## Routes

Home, About, Products, five category destinations (including General Order Supplies), Contact, Privacy, Cookies, custom 404 and route-error handling. Read-only API: `/api/categories?q=carbide&group=cutting`. Groups: all, cutting, accessories, supplies. `/api/health` checks PostgreSQL through Drizzle.

## Enquiries are not pretend submissions

The confirmed mailto address is m.afeefchaudhry247@gmail.com. The contact utility prepares an email locally; users review and send it in their own email application. It has explicit draft/not-sent states and a copy fallback. No enquiry is stored or submitted to the server. No SMTP provider, account, key, WhatsApp number, map embed, analytics, cookie banner, or paid service has been added.

## Content updates

Public category fields are defined in `src/lib/content.ts`, with database schema in `src/db/schema.ts`. Hero and business copy are server-rendered in route components; small interactions are isolated client components. Category pages and catalogue use the database. The homepage and other stable pages are statically rendered. Database reads use `@/db` and Drizzle only.

Do not add inventory, prices, brand affiliation, specifications, customer reviews, certifications, phone numbers, opening hours, or promises without owner confirmation. Examples and imagery are labelled illustrative. No supplied logo was present, so navigation uses plain business-name text, not a fabricated reproduction. Add the actual, intact supplied logo once available and review its palette/clearspace.

## Design and performance

Design tokens live at the start of globals.css. Max content width 1320px; one/two/four-column responsive grids. Manrope variable font is self-hosted (24 KB). Stock images are local and Next Image generates responsive WebP/AVIF. The hero uses photographic CSS depth instead of a large WebGL bundle and respects reduced motion/coarse pointers. No runtime third-party scripts. Asset sources and font license are retained.

## Validation

- `npx next typegen`
- `npm exec tsc -- --noEmit --pretty false`
- `npm run lint`
- `npx tsx --test src/lib/content.test.ts`
- `npm run build`
- Platform `build_and_start` for production startup/health.
- `npx playwright test` against the running production preview (default http://127.0.0.1:3000; override PLAYWRIGHT_BASE_URL).

For a fresh test environment, install browser support with `npx playwright install --with-deps chromium`. Tests cover customer journeys, API filters, error/empty states, local drafts, correct email recipient, mobile navigation, reduced motion, images, 404, keyboard focus, automated axe A/AA scans and responsive overflow. Automated scans are not a full accessibility certification. No Lighthouse or field Core Web Vitals score is claimed.

## Production gate and operations

Set SITE_URL only to an approved canonical HTTPS domain. Without it, robots/meta discourage preview indexing and the sitemap contains no invented URLs. Configured pages get unique canonical/social metadata. LocalBusiness structured data contains confirmed facts only. Review privacy/cookies drafts, owner contact details, and the final host’s logging/data-retention settings. Review CSP inline-script allowances for Next.js before public rollout.

No public deployment, domain/DNS change, account creation, or purchase was performed. Production hosting pricing/free-tier claims are intentionally not invented. Choose a suitable Node/PostgreSQL host with owner approval, back up the database before migrations, retain immutable builds, and use the host’s previous-build rollback mechanism. No destructive migration or Git reset was performed; no Git repository existed on discovery.

The dependency audit is recorded in docs/QA-REPORT.md. Do not blindly apply breaking `npm audit fix --force` upgrades.

## Review documents

- docs/BUILD-PLAN.md — strategy, architecture, skill audit, roadmap, costs and owner-confirmation register.
- docs/ASSET-SOURCES.md — source/licence notes and logo status.
- docs/QA-REPORT.md — verification outcomes and limitations.

The four requested skills (Impeccable, UI UX Pro Max, Frontend Design, Canvas Design) were not found in the readable environment paths. None were invoked or installed.
