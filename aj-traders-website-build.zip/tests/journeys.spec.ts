import { test, expect } from "@playwright/test";

const email = "m.afeefchaudhry247@gmail.com";

test("home → products → carbide → enquiry", async ({ page }) => {
  await page.goto("/");
  await expect(page.getByRole("heading", { level: 1 })).toContainText("Precision tools.");
  await page.getByRole("link", { name: "Explore product categories", exact: true }).click();
  await expect(page).toHaveURL(/\/products$/);
  await expect(page.locator(".category-card")).toHaveCount(5);
  await page.locator(".category-card").filter({ hasText: "Carbide cutting tools" }).click();
  await expect(page.getByRole("heading", { level: 1 })).toContainText("Carbide cutting tools");
  await page.getByRole("link", { name: "Enquire about this category" }).click();
  await expect(page).toHaveURL(/\/contact\?category=carbide-cutting-tools/);
  await expect(page.getByLabel("Area of interest")).toHaveValue("carbide-cutting-tools");
});

test("database search, filters, and empty-state recovery", async ({ page }) => {
  await page.goto("/products");
  await page.getByRole("button", { name: "Cutting tools", exact: true }).click();
  await expect(page.locator(".category-card")).toHaveCount(2);
  await page.getByRole("button", { name: "All categories", exact: true }).click();
  await expect(page.locator(".category-card")).toHaveCount(5);
  await page.getByRole("searchbox", { name: "Search product categories" }).fill("carbide");
  await expect(page.locator(".category-card")).toHaveCount(1);
  await expect(page).toHaveURL(/q=carbide/);
  await page.getByRole("searchbox", { name: "Search product categories" }).fill("nothing-matches-this");
  await expect(page.getByRole("heading", { name: "No categories found." })).toBeVisible();
  await page.getByRole("button", { name: "Clear search & filters" }).click();
  await expect(page.locator(".category-card")).toHaveCount(5);
});

test("header search and keyboard-closeable product navigation", async ({ page }) => {
  await page.goto("/");
  await page.getByRole("button", { name: "Products", exact: true }).click();
  await expect(page.locator("#products-menu")).toBeVisible();
  await page.keyboard.press("Escape");
  await expect(page.locator("#products-menu")).not.toBeVisible();
  await page.getByRole("button", { name: "Search product categories" }).click();
  await expect(page.getByRole("dialog", { name: "What are you looking for?" })).toBeVisible();
  await page.getByRole("textbox", { name: "Search categories", exact: true }).fill("CNC");
  await page.getByRole("button", { name: "Search", exact: true }).click();
  await expect(page).toHaveURL(/\/products\?q=CNC/);
  await expect(page.locator(".category-card")).toHaveCount(1);
});

test("honest local email draft and correct recipient", async ({ page }) => {
  await page.goto("/contact?category=cnc-accessories");
  await expect(page.locator(".contact-email")).toHaveAttribute("href", `mailto:${email}`);
  await page.getByLabel("Your name").fill("Procurement Buyer");
  await page.getByLabel("Company / workshop").fill("Test workshop");
  await page.getByLabel("What do you need?").fill("Please discuss a tool holder requirement and the dimensions needed.");
  await page.getByRole("button", { name: "Prepare email draft" }).click();
  await expect(page.getByText("YOUR DRAFT IS READY — NOT SENT")).toBeVisible();
  await expect(page.getByRole("link", { name: "Open in email app" })).toHaveAttribute("href", new RegExp(`^mailto:${email.replaceAll(".", "\\.")}\\?subject=`));
  await expect(page.locator(".draft-preview")).toContainText("Procurement Buyer");
  await expect(page.locator(".draft-preview")).toContainText("CNC accessories");
  await page.getByRole("button", { name: "Edit your draft" }).click();
  await expect(page.getByLabel("Your name")).toHaveValue("Procurement Buyer");
  expect(await page.evaluate(() => localStorage.length)).toBe(0);
});

test("enquiry draft rejects whitespace-only details", async ({ page }) => {
  await page.goto("/contact");
  await page.getByLabel("Your name").fill("   ");
  await page.getByLabel("What do you need?").fill("                     ");
  await page.getByRole("button", { name: "Prepare email draft" }).click();
  await expect(page.locator(".enquiry-composer").getByRole("alert")).toContainText("excluding leading and trailing spaces");
  await expect(page.getByText("YOUR DRAFT IS READY — NOT SENT")).not.toBeVisible();
});

test("mobile menu opens, navigates, and closes", async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto("/");
  await page.getByRole("button", { name: "Open navigation menu" }).click();
  const dialog = page.getByRole("dialog", { name: "Mobile navigation", exact: true });
  await expect(dialog).toBeVisible();
  await dialog.getByRole("link", { name: "CNC accessories", exact: true }).click();
  await expect(page).toHaveURL(/\/products\/cnc-accessories/);
  await expect(dialog).not.toBeVisible();
  await expect(page.getByRole("heading", { level: 1 })).toContainText("CNC accessories");
  await page.getByRole("link", { name: "Enquire about this category" }).click();
  await expect(page).toHaveURL(/\/contact\?category=cnc-accessories/);
});

test("about, general supplies, legal links, and genuine 404", async ({ page, request }) => {
  await page.goto("/about");
  await expect(page.getByRole("heading", { name: "M. Afeef Chaudhry" })).toBeVisible();
  await page.locator("footer").getByRole("link", { name: "Privacy policy" }).click();
  await expect(page.getByRole("heading", { level: 1 })).toContainText("Privacy policy");
  await page.locator("footer").getByRole("link", { name: "Cookie policy" }).click();
  await expect(page.getByRole("heading", { level: 1 })).toContainText("Cookie policy");
  await page.goto("/general-order-supplies");
  await expect(page.getByRole("heading", { level: 1 })).toContainText("General industrial supplies");
  const response = await request.get("/a-non-existent-page");
  expect(response.status()).toBe(404);
  await page.goto("/a-non-existent-page");
  await expect(page.getByRole("heading", { level: 1 })).toContainText("right tool");
});

test("catalogue API validates inputs and returns database results", async ({ request }) => {
  const all = await request.get("/api/categories");
  expect(all.ok()).toBeTruthy();
  expect((await all.json()).total).toBe(5);
  const filtered = await request.get("/api/categories?group=cutting&q=HSS");
  expect((await filtered.json()).categories[0].slug).toBe("hss-cutting-tools");
  expect((await request.get("/api/categories?group=invalid")).status()).toBe(400);
  expect((await request.get(`/api/categories?q=${"x".repeat(101)}`)).status()).toBe(400);
  expect((await request.get("/api/health")).ok()).toBeTruthy();
});

test("responsive widths, local assets, reduced motion, no page errors", async ({ page }) => {
  const errors: string[] = [];
  page.on("pageerror", error => errors.push(error.message));
  for (const width of [360, 390, 768, 1440]) {
    await page.setViewportSize({ width, height: 900 });
    await page.goto("/");
    await page.locator(".home-about").scrollIntoViewIfNeeded();
    await page.locator("footer").scrollIntoViewIfNeeded();
    await expect.poll(async () => page.evaluate(() => [...document.images].filter(i => !i.complete || i.naturalWidth === 0).length)).toBe(0);
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBeTruthy();
  }
  await page.emulateMedia({ reducedMotion: "reduce" });
  await page.goto("/");
  await expect(page.getByRole("heading", { level: 1 })).toBeVisible();
  expect(await page.locator(".hero-visual").evaluate(el => getComputedStyle(el).transform)).toBe("none");
  expect(await page.locator('a[href*="wa.me"], iframe, script[src*="googletag"]').count()).toBe(0);
  expect(errors).toEqual([]);
});
