import { test, expect } from "@playwright/test";
import AxeBuilder from "@axe-core/playwright";

for (const path of ["/", "/products", "/contact", "/about", "/products/carbide-cutting-tools", "/privacy"]) {
  test(`automated WCAG A/AA checks: ${path}`, async ({ page }) => {
    await page.goto(path);
    const results = await new AxeBuilder({ page }).withTags(["wcag2a", "wcag2aa", "wcag21aa", "wcag22aa"]).analyze();
    expect(results.violations).toEqual([]);
  });
}

test("keyboard search dialog focus and mobile dialog accessibility", async ({ page }) => {
  await page.goto("/");
  const search = page.getByRole("button", { name: "Search product categories" });
  await search.focus();
  await page.keyboard.press("Enter");
  await expect(page.getByRole("textbox", { name: "Search categories", exact: true })).toBeFocused();
  const searchScan = await new AxeBuilder({ page }).withTags(["wcag2a", "wcag2aa", "wcag21aa", "wcag22aa"]).analyze();
  expect(searchScan.violations).toEqual([]);
  await page.keyboard.press("Escape");
  await expect(search).toBeFocused();
  await page.setViewportSize({ width: 390, height: 844 });
  await page.getByRole("button", { name: "Open navigation menu" }).click();
  const mobileScan = await new AxeBuilder({ page }).withTags(["wcag2a", "wcag2aa", "wcag21aa", "wcag22aa"]).analyze();
  expect(mobileScan.violations).toEqual([]);
  await page.keyboard.press("Escape");
  await expect(page.getByRole("button", { name: "Open navigation menu" })).toBeFocused();
});

test("inner pages do not overflow at mobile and tablet widths", async ({ page }) => {
  test.setTimeout(60000);
  for (const width of [360, 768]) {
    await page.setViewportSize({ width, height: 900 });
    for (const path of ["/products", "/about", "/contact", "/products/carbide-cutting-tools", "/products/hss-cutting-tools", "/products/cnc-accessories", "/products/drilling-milling-accessories", "/general-order-supplies", "/privacy", "/cookies", "/not-a-page"]) {
      await page.goto(path);
      await expect(page.getByRole("heading", { level: 1 })).toBeVisible();
      expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth), `${path} at ${width}px`).toBeTruthy();
    }
  }
});
